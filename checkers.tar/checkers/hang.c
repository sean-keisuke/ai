#include <stdlib.h>
#include <stdio.h>
#include <time.h>

int main(int argc, char *argv[])
{
    while(1)
    {
       //fprintf(stderr,"%i\n", time(NULL));
       //fflush(stderr);
    }
}
